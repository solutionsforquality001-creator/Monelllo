import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, transactions } from "@/db/schema";
export async function POST(req: NextRequest) {
  try {
    const { amount, crypto } = await req.json();
    const u = await db.select().from(users).limit(1);
    if (u.length) {
      await db.insert(transactions).values({ userId: u[0].id, type: "deposit", amount: String(amount), method: crypto, status: "confirmed" });
    }
    return NextResponse.json({ ok: true });
  } catch (e: any) { return NextResponse.json({ ok: true }); }
}
