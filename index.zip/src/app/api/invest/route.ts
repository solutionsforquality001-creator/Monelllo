import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { investments, users } from "@/db/schema";

export async function POST(req: NextRequest) {
  try {
    const { plan, amount } = await req.json();
    // try to store if user exists, else just acknowledge
    const allUsers = await db.select().from(users).limit(1);
    if (allUsers.length) {
      const planMap: any = {
        starter: { roi: 25, days: 3 },
        gold: { roi: 55, days: 7 },
        realestate: { roi: 70, days: 14 },
        real_estate: { roi: 70, days: 14 },
      };
      const meta = planMap[plan] || { roi: 25, days: 7 };
      const expected = Math.round(amount * (1 + meta.roi / 100));
      const end = new Date(Date.now() + meta.days * 24 * 60 * 60 * 1000);
      await db.insert(investments).values({
        userId: allUsers[0].id,
        plan,
        amount: String(amount),
        roiPercent: meta.roi,
        durationDays: meta.days,
        endDate: end,
        expectedReturn: String(expected),
      });
    }
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ ok: true, warning: e.message });
  }
}

export async function GET() {
  try {
    const data = await db.select().from(investments).limit(20);
    return NextResponse.json(data);
  } catch (e: any) {
    return NextResponse.json([]);
  }
}
